# -*- coding:utf-8 -*-
#!/usr/bin/env python

from __future__ import division

import re
import sys

from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types
import pyaudio
from six.moves import queue
# [END import_libraries]
import threading
import os
import SmartMirrorUI
import YouTubeDisplayer

LOCALE_LOCK = threading.Lock()

isStreaming = ""

os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="C:/Users/Developer/PycharmProjects/untitled1/Speech-api.json"

# 오디오 레코딩 파라미터
RATE = 30000
CHUNK = int(RATE / 10)  # 100ms

class MicrophoneStream(object):
    #오디오 덩어리를 제너레이터의 yield로 받아 레코딩 스트림을 처리한다.
    def __init__(self, rate, chunk):
        self._rate = rate
        self._chunk = chunk
        self.player = ""
        # 오디오 데이터의 thread-safe buffer를 생성.
        self._buff = queue.Queue()
        self.closed = True

    def __enter__(self):
        self._audio_interface = pyaudio.PyAudio()
        self._audio_stream = self._audio_interface.open(
            format=pyaudio.paInt16,
            # The API currently only supports 1-channel (mono) audio
            # https://goo.gl/z757pE
            channels=1, rate=self._rate,
            input=True, frames_per_buffer=self._chunk,
            # Run the audio stream asynchronously to fill the buffer object.
            # This is necessary so that the input device's buffer doesn't
            # overflow while the calling thread makes network requests, etc.
            stream_callback=self._fill_buffer,
        )

        self.closed = False

        return self

    def __exit__(self, type, value, traceback):
        self._audio_stream.stop_stream()
        self._audio_stream.close()
        self.closed = True
        # Signal the generator to terminate so that the client's
        # streaming_recognize method will not block the process termination.
        self._buff.put(None)
        self._audio_interface.terminate()

    def _fill_buffer(self, in_data, frame_count, time_info, status_flags):
        """Continuously collect data from the audio stream, into the buffer."""
        self._buff.put(in_data)
        return None, pyaudio.paContinue

    def generator(self):
        while not self.closed:
            chunk = self._buff.get()
            if chunk is None:
                return
            data = [chunk]

            # Now consume whatever other data's still buffered.
            while True:
                try:
                    chunk = self._buff.get(block=False)
                    if chunk is None:
                        return
                    data.append(chunk)
                except queue.Empty:
                    break

            yield b''.join(data)

    def input_command(self):
        global isStreaming
        keyword = '동영상|영상|유튜브|재생|틀어'
        keyword2= '닫아|꺼|정지'
        key = re.compile(keyword)
        key2 = re.compile(keyword2)
        # keyword = ['동영상', '영상', '유튜브', '재생', '틀어']
        isStreaming = False

        while True:
            ic = (yield)
            if key.search(ic):
                t1 = threading.Thread(target=YouTubeDisplayer.display_youtube,
                                      args=(root, ic, isStreaming, self,))
                t1.start()
                isStreaming = True
            elif key2.search(ic):
                t1 = threading.Thread(target=YouTubeDisplayer.display_close, args=(self,))
                t1.start()
                isStreaming = False
            else:
                print("동영상이 아닙니다.")
            # m = p.match(ic)
            # for key in keyword:
            #     m = re.search(key, ic)
            #     if m is not None:
            #         haskeyword = True
            #         break
            #
            # if haskeyword:
            #     try:
            #        print(ic)
            #        t1 = threading.Thread(target=)
            #        t1.start()
            #     except:
            #         print("재생 실패")
            #
            #     haskeyword = False
            # else:
            #     print("올바른 명령어가 아닙니다.")
# [END audio_stream]

def listen_print_loop(responses, stream):

    ic = stream.input_command()
    next(ic)

    num_chars_printed = 0
    for response in responses:
        if not response.results:
            continue

        result = response.results[0]

        if not result.alternatives:
            continue

        transcript = result.alternatives[0].transcript

        overwrite_chars = ' ' * (num_chars_printed - len(transcript))

        if not result.is_final:
            sys.stdout.write(transcript + overwrite_chars + '\r')
            sys.stdout.flush()

            num_chars_printed = len(transcript)

        else:
            #여기서 코루틴을 이용해서 명령어 처리 넣기.
            ic.send(transcript + overwrite_chars)
            if re.search(r'\b(exit|quit)\b', transcript, re.I):
                print('Exiting..')
                break

            num_chars_printed = 0


def StartSpeech(tk_root):
    #root 매개변수 추가 - test를 위해서
    print("StartSpeech")
    global root
    root = tk_root
    # See http://g.co/cloud/speech/docs/languages
    # for a list of supported languages.
    language_code = 'ko-KR'  # a BCP-47 language tag

    client = speech.SpeechClient()
    config = types.RecognitionConfig(
        encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=RATE,
        language_code=language_code)
    streaming_config = types.StreamingRecognitionConfig(
        config=config,
        interim_results=True)

    with MicrophoneStream(RATE, CHUNK) as stream:
        audio_generator = stream.generator()
        requests = (types.StreamingRecognizeRequest(audio_content=content)
                    for content in audio_generator)

        responses = client.streaming_recognize(streaming_config, requests)
        # Now, put the transcription responses to use.
        listen_print_loop(responses, stream)
