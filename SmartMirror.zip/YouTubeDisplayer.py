# -*- coding:utf-8 -*-
#!/usr/bin/env python

from tkinter import *
from tkinter import ttk
from tkinter.filedialog import askopenfilename
from apiclient.discovery import build
from apiclient.errors import HttpError
from oauth2client.tools import argparser
from six.moves import queue
import threading
import sys
import json
import urllib
import urllib.request
import platform

import pafy
import vlc

LOCALE_LOCK = threading.Lock()

DEVELOPER_KEY = "AIzaSyBfxBMi3ytFSrcBxbKw8CaerNOM8uxsTZo"
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"


def youtube_search(query, limit):  # 첫 번째 파라미터인 mid 잠시 주석처리.
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
                    developerKey=DEVELOPER_KEY)

    youtube_video_url = "https://www.youtube.com/watch?v={0}"
    youtube_playlist_url = "https://www.youtube.com/playlist?list={0}"
    youtub_channel_url = "https://www.youtube.com/channel/{0}"

    # Call the search.list method to retrieve results associated with the
    # specified Freebase topic.
    search_response = youtube.search().list(
        q=query,
        part="id,snippet",
        maxResults=limit
    ).execute()

    videos = []  # if type is video,.
    playlists = []  # if type is playlist.
    channels = []  # if type is channel.

    # Print the title and ID of each matching resource.
    for search_result in search_response.get("items", []):
        if search_result["id"]["kind"] == "youtube#video":
            videos.append('%s' % (search_result['id']['videoId']))  # video input
        elif search_result["id"]["kind"] == "youtube#channel":
            playlists.append('%s' % (search_result['id']['channelId']))
        elif search_result["id"]["kind"] == "youtube#playlist":
            playlists.append('%s' % (search_result['id']['playlistId']))

    url = ""

    if videos:
        url = youtube_video_url.format(videos[0])
    elif playlists:
        url = youtube_playlist_url.format(playlists[0])
    elif channels:
        url = youtub_channel_url.format(channels[0])

    video = pafy.new(url)
    best = video.getbest()
    playurl = best.url

    return playurl


class Player(Frame):
    """The main windwo has to deal with events.
    """
    # root를 parent로 하는 Frame만들기.
    def __init__(self, parent, youtube_url, title="tk_vlc"):
        Frame.__init__(self, parent)
        self.parent = parent

        self.youtube_url = youtube_url
        self.player = None
        self.videopanel = ttk.Frame(self.parent)
        self.canvas = Canvas(self.videopanel).pack(fill=BOTH, expand=1)
        self.videopanel.pack(fill=None, expand=1)

        #ctrlpanel = ttk.Frame(self.parent)
        #pause = ttk.Button(ctrlpanel, text="Pause", command=self.OnPause)
        # play = ttk.Button(ctrlpanel, text="Play", command=self.OnPlay)
        #stop = ttk.Button(ctrlpanel, text="Stop", command=self.OnStop)
        #volume = ttk.Button(ctrlpanel, text="Volume", command=self.OnSetVolume)
        #pause.pack(side=LEFT)
        # play.pack(side=Tk.LEFT)
        #stop.pack(side=LEFT)
        #volume.pack(side=LEFT)

        #self.volume_var = IntVar()
        #self.volslider = Scale(ctrlpanel, variable=self.volume_var, command=self.volume_sel, from_=0, to=100,
        #                       orient=HORIZONTAL, length=100)
        #self.volslider.pack(side=LEFT)
        #ctrlpanel.pack(side=BOTTOM)

        # VLC player controls
        self.Instance = vlc.Instance()
        self.player = self.Instance.media_player_new()

        self.OnPlay(self.youtube_url)
        # self.timer = ttkTimer(self.OnTimer, 1.0)
        # self.timer.start()
        # self.parent.update()

    def OnPlay(self, url):
        """Toggle the status to Play/Pause.
        If no file is loaded, open the dialog window.
        """
        # check if there is a file to play, otherwise open a
        # Tk.FileDialog to select a file
        self.Media = self.Instance.media_new(url)
        self.player.set_media(self.Media)

        # set the window id where to render VLC's video output
        if platform.system() == 'Windows':
            self.player.set_hwnd(self.GetHandle())
        else:
            self.player.set_xwindow(self.GetHandle())  # this line messes up windows
        # FIXME: this should be made cross-platform

        # Try to launch the media, if this fails display an error message
        if self.player.play() == -1:
            self.errorDialog("Unable to play.")

    def GetHandle(self):
        return self.videopanel.winfo_id()

    def OnPause(self):
        """Pause the player.
        """
        self.player.pause()

    def OnStop(self):
        """Stop the player.
        """
        self.player.stop()
        # reset the time slider

    def volume_sel(self, evt):
        if self.player == None:
            return
        volume = self.volume_var.get()
        if volume > 100:
            volume = 100
        if self.player.audio_set_volume(volume) == -1:
            self.errorDialog("Failed to set volume")

    def OnToggleVolume(self, evt):
        """Mute/Unmute according to the audio button.
        """
        is_mute = self.player.audio_get_mute()

        self.player.audio_set_mute(not is_mute)
        # update the volume slider;
        # since vlc volume range is in [0, 200],
        # and our volume slider has range [0, 100], just divide by 2.
        self.volume_var.set(self.player.audio_get_volume())

    def OnSetVolume(self):
        """Set the volume according to the volume sider.
        """
        volume = self.volume_var.get()
        # vlc.MediaPlayer.audio_set_volume returns 0 if success, -1 otherwise
        if volume > 100:
            volume = 100
        if self.player.audio_set_volume(volume) == -1:
            self.errorDialog("Failed to set volume")

    def errorDialog(self, errormessage):
        """Display a simple error dialog.
        """
        Tk.tkMessageBox.showerror(self, 'Error', errormessage)

def display_close(stream):
    stream.player.OnStop()
    stream.player.videopanel.destroy()

def display_youtube(root, command, isStreaming, stream):
    youtube_url = ""
    query = command
    limit = 10

    try:
        youtube_url = youtube_search(query, limit)
    except HttpError as e:
        print("An HTTP error %d occurred:\n%s" % (e.resp.status, e.content))

    # root.mainloop()
    if isStreaming is True:
        stream.player.OnPlay(youtube_url)
    elif isStreaming is False:
        stream.player=Player(root, youtube_url, title="YouTube Display")

